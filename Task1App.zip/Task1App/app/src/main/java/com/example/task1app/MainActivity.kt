package com.example.task1app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Task1Screen()
        }
    }
}

@Composable
fun Task1Screen() {
    Surface(color = MaterialTheme.colorScheme.background) {
        Text(
            text = "Task 1 Completed Successfully!",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
